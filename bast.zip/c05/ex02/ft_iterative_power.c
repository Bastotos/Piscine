/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/04 12:26:52 by broumeng          #+#    #+#             */
/*   Updated: 2024/03/04 13:42:54 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	j;

	i = 1;
	j = nb;
	if (power == 0)
		return (1);
	if (power < 0)
		return (0);
	if (nb < 0)
		nb = -nb;
	while (i < power)
	{
		nb = nb * j;
		i++;
	}
	return (nb);
}
/*
#include <stdio.h>

int main()
{
	printf("%d\n", ft_iterative_power(20, 0));
	printf("%d\n", ft_iterative_power(2, 3));
	printf("%d\n", ft_iterative_power(-4, 4));
}*/
