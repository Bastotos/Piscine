/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/29 14:33:18 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/29 15:32:23 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	i;

	i = 1;
	if (nb < 0)
		return (0);
	while (nb != 0)
	{
		i *= nb;
		nb--;
	}
	return (i);
}
/*
#include <stdio.h>
#include <stdlib.h>

int main(int ac, char **av)
{
	int b;
	b = atoi(av[1]);
	printf("%d", ft_iterative_factorial(b));
}*/
