/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/04 12:56:27 by broumeng          #+#    #+#             */
/*   Updated: 2024/03/04 13:54:13 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	int	i;
	int	j;

	i = 1;
	if (power == 0)
		return (1);
	if (nb < 0)
		nb = -nb;
	j = nb;
	if (power < 0)
	{
		while (i > power)
		{
			nb = nb * j;
			i--;
		}
		return (1 / nb);
	}
	if (power > 0)
	{
		while (i < power)
		{       
			nb = nb * j;
			i++;
		}       
		return (nb);
	}
	return (0);
}
#include <stdio.h>

int	main()
{
	printf("%d\n", ft_recursive_power(2, -2));
	printf("%d\n", ft_recursive_power(2, 2));
	printf("%d\n", ft_recursive_power(2, 0));
}
