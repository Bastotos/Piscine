/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/24 12:43:17 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/24 13:49:10 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


void	swap(int *a, int *b)
{
       	int	c;
	c = *a;
	*a = *b;
	*b = c;
}

int	verifie(int	*tab)
{
	int	i;
	int	k;
	int 	tabc;
	int	tac;

	&tab = tabc;
	tac[] = {1, 2, 3, 4};
	i = 0;
	while (i <= 4)
	{
		k = i;
		while (k <= 3)
		{
			if (tabc[i] > tabc[k])
			swap(tabc + i, tabc + k);
		}
		k++;
	}
	i++;
	if (tabc == tac)
		return (1);
	else
		return (0);
}
#include <stdio.h>

int main()
{
	int	tab[] = {3, 3, 3, 3};
	int	tab1[] = {4,2,1,3};

	printf("%d\n", verifie(tab));
	printf("%d\n", verifie(tab1));
}
