/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utile.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/02 14:08:12 by broumeng          #+#    #+#             */
/*   Updated: 2024/03/02 14:42:44 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_len(char *chaine)
{
	int	i;

	i = 0;
	while (chaine[i])
		i++;
}

int	ft_atoi(char *chaine)
{
	int	i;
	int	n;
	int	r;

	i = 0;
	n = 1;
	r = 0;
	while (chaine[i])
	{
		if (chaine[i] == ' ' || chaine[i] == '\n' || chaine[i] == '\t'
			|| chaine[i] == '\v' || chaine[i] == '\f' || chaine[i] == '\r')
			i++;
		if (chaine[i] == '+' || chaine[i] == '-')
		{
			if (chaine[i] == '-')
				n = n * -1;
			i++;
		}
		if (chaine[i] >= '0' && chaine[i] <= '9')
		{
			r = r * 10 + chaine[i] - '0';
			i++;
		}
		return (r * n);
	}
}

void	putstr(char *c)
{
	int	i;

	i = 0;
	while (c[i])
	{
		write(1, &c[i], 1);
		i++;
	}
}
