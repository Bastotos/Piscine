git log -n5 --format=%H
