/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 12:02:25 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/20 11:44:22 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;

	div = (*a / *b);
	mod = (*a % *b);
	*a = div;
	*b = mod;
}
/*
#include <stdio.h>

int	main()
{
	int	a;
	int	b;

	a = 10;
	b = 2;
	printf("%d\n%d\n", a, b);
	ft_ultimate_div_mod(&a, &b);
	printf("%d\n%d\n", a, b);
}*/
