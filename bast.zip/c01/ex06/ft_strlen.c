/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 12:45:15 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/19 13:25:46 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int		i;
	char	nulle;

	i = 0;
	nulle = '\0';
	while (str[i] != nulle)
	{
		i++;
	}
	return (i);
}
/*
int main()
{
	ft_strlen("ching cheng hanji");
}
*/
