/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 14:16:35 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/25 11:53:10 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;

	i = 0;
	while (i < size / 2)
	{
		swap(&tab[i], &tab[size - i + 1]);
		i++;
	}
}
/*
#include <stdio.h>

int main()
{
        int     tab[11] = {0, 5, 9, 10, 8, 7, 3, 2, 1, 4, 6};
        int     size = 11;

        ft_rev_int_tab(tab, 11);
        int i;

        i = 0;
        while (i < size) {
                printf("%d ", tab[i]);
                i++;
        }
        printf("\n");
}*/
