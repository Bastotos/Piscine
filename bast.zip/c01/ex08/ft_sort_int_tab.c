/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 14:57:39 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/24 13:50:10 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	k;

	i = 0;
	while (i <= size)
	{
		k = i;
		while (k <= size - 1)
		{
			if (tab[i] > tab[k])
			{
				swap(tab + i, tab + k);
			}
			k++;
		}
		i++;
	}
}
/*
#include <stdio.h>
int main()
{
	int	tab[10] = {0, 5, 9, 8, 7, 3, 2, 1, 4, 6};
	int	size = 10;

	ft_sort_int_tab(tab, 10);
	int i;

	i = 0;
	while (i < size) {
		printf("%d ", tab[i]);
		i++;
	}
	printf("\n");
}*/
