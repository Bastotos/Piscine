/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 12:10:23 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/19 12:43:16 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		i;
	char	nulle;

	nulle = '\0';
	i = 0;
	while (str[i] != nulle)
	{
		ft_putchar(str[i]);
		i++;
	}
}
/*
int main ()
{
	ft_putstr("gneuuuuueeueu");

}
*/
