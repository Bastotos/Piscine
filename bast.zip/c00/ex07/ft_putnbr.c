/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/16 11:29:31 by broumeng          #+#    #+#             */
/*   Updated: 2024/03/01 11:33:19 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char a)
{
	write(1, &a, 1);
}

void	ft_putnbr(int nb)
{
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb == 2147483647)
	{
		write(1, "2147483647", 11);
	}
	else
	{
		if (nb >= 10)
		{
			ft_putnbr(nb / 10);
			ft_putchar(nb % 10 + '0');
		}
		if (nb < 10 && nb > 0)
		{
			ft_putchar(nb + '0');
		}
	}
}
/*
#include <stdio.h>

int main()
{
	int	i;
	int	j;

	i = 4578;
	j = -2147483647;
	ft_putnbr(i);
	ft_putnbr(j);
}*/
