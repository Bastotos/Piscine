/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: broumeng <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 15:13:43 by broumeng          #+#    #+#             */
/*   Updated: 2024/02/18 15:01:58 by broumeng         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	put_number(int n)
{
	if (n < 10)
	{
		ft_putchar('0');
		ft_putchar(n + '0');
	}
	else
	{
		ft_putchar(n / 10 + '0');
		ft_putchar(n % 10 + '0');
	}
}

void	affiche(int c, int d)
{
	put_number(c);
	ft_putchar(' ');
	put_number(d);
	if (c == 98 && d == 99)
	{
	}
	else
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_comb2(void)
{
	int	i;
	int	k;

	i = 0;
	while (i <= 99)
	{
		k = i;
		while (k <= 99)
		{
			if (i != k)
			{
				affiche(i, k);
			}
			k++;
		}
		i++;
	}
}
